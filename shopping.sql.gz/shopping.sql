-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2020 at 12:33 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(5) NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `phone`, `address`) VALUES
(1, 'Haha', 'haha@gmail.com', '0978505341', 'Yangon'),
(2, 'Aung Aung', 'hehe@gmail.com', '907854741', 'Yangon'),
(3, 'mohamad khalif', 'hello@email.com', '09772592621', 'Yangon'),
(4, 'mohamad khalif', 'robertohlamoe1221@gmail.com', '09797298739', 'Yangon'),
(5, 'computer', 'ahaha@gmail.com', '09772592621', 'hehehehe'),
(6, 'computer', 'hahaha@gmail.com', '09797298739', 'hehehehe');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(10) NOT NULL,
  `item_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `brand` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `review` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(10) NOT NULL,
  `qty` int(11) NOT NULL,
  `photo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `reach_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `brand`, `price`, `review`, `category_id`, `qty`, `photo`, `reach_date`) VALUES
(8, '1987', 'Authenic American Brand Durabale shirt', 15000, 'Very Good', 4, 1000, 'shin_yoon_myat.jpg', '2020-09-19'),
(9, '1987', 'Authenic American Brand Durabale shirt', 15000, 'Very Good', 8, 100, 'shin_yoon_myat2.jpg ', '2020-09-24'),
(10, 'Yolo', 'Polo Sub Brand ', 25000, 'Fair', 4, 100, 'pro_3_1.PNG ', '2020-09-24'),
(11, 'Kimbra', 'Authenic American Brand Durabale shirt', 150000, 'Very good and more fair price than Polo, Discounts are fotern', 4, 100, 'polo_shirt.jpg', '2020-09-24'),
(12, 'Nani Naviea', 'For Caring Skin ', 10000, 'Very Good', 13, 50, 'cutie.png ', '2020-09-24');

-- --------------------------------------------------------

--
-- Table structure for table `order_customer`
--

CREATE TABLE `order_customer` (
  `id` int(5) NOT NULL,
  `order_id` int(5) NOT NULL,
  `customer_id` int(5) NOT NULL,
  `day` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_customer`
--

INSERT INTO `order_customer` (`id`, `order_id`, `customer_id`, `day`) VALUES
(1, 0, 0, '2020-09-26'),
(2, 1, 1, '2020-09-26'),
(3, 0, 0, '2020-09-26');

-- --------------------------------------------------------

--
-- Table structure for table `pro_catories`
--

CREATE TABLE `pro_catories` (
  `id` int(5) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pro_catories`
--

INSERT INTO `pro_catories` (`id`, `name`, `description`) VALUES
(4, 'Men', 'For Men Wear'),
(8, 'Women', 'Wears for Women'),
(13, 'Skin care', 'Naviea'),
(14, 'New Famous Skin Care', 'Follow Me Liquid Skin care');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(2) NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `order_customer`
--
ALTER TABLE `order_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_catories`
--
ALTER TABLE `pro_catories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `order_customer`
--
ALTER TABLE `order_customer`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pro_catories`
--
ALTER TABLE `pro_catories`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `pro_catories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
